
-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `Customer_ID` int NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `Location` varchar(250) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `PhoneNumber` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Customer_ID`, `CustomerName`, `Location`, `Email`, `PhoneNumber`) VALUES
(3, 'Arnold', 'Bulacan', 'arnold.arnold@gmail.com', 938274753),
(4, 'Peter', 'Caloocan', 'Peter_pete@gmail.com', 903850356),
(5, 'Mike', 'Valenzuela', 'Mike.Val@gmail.com', 903850356),
(6, 'Jake', 'Navotas', 'Jake24@gmail.com', 983271642),
(7, 'Gilbert', 'Sangandaan', 'Gilbert000@gmail.com', 982713245),
(8, 'Angelo', 'Caloocan', 'angelo35@gmail.com', 938275621);
