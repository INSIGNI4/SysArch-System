
-- --------------------------------------------------------

--
-- Table structure for table `customersreturns`
--

CREATE TABLE `customersreturns` (
  `CReturn_ID` int NOT NULL,
  `ReferenceNo` varchar(100) NOT NULL,
  `Quantity` int NOT NULL,
  `ReturnedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ReasonForReturn` enum('Wrong-Item','Damaged','Not-Match','Faulty','Missing-Parts','Not-Fit','Accidental','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Customer_ID` int DEFAULT NULL,
  `Product_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customersreturns`
--

INSERT INTO `customersreturns` (`CReturn_ID`, `ReferenceNo`, `Quantity`, `ReturnedDate`, `ReasonForReturn`, `Customer_ID`, `Product_ID`) VALUES
(21, '20250900001', 1, '2025-10-17 05:16:33', 'Wrong-Item', 4, 2),
(22, '20250900001', 1, '2025-10-17 05:16:45', 'Damaged', 4, 4),
(23, '20250900001', 1, '2025-10-17 05:16:55', 'Not-Match', 4, 3),
(24, '20250900001', 1, '2025-10-17 05:17:07', 'Faulty', 4, 4),
(25, '20250900001', 1, '2025-10-17 05:17:17', 'Missing-Parts', 6, 2),
(26, '20250900002', 1, '2025-10-17 05:17:31', 'Not-Fit', 4, 7),
(27, '20250900001', 1, '2025-10-17 05:17:42', 'Accidental', 6, 4),
(28, '20250900001', 1, '2025-10-17 05:17:51', 'Other', 4, 3);
