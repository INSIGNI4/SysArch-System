
-- --------------------------------------------------------

--
-- Table structure for table `expiration`
--

CREATE TABLE `expiration` (
  `Expiration_ID` int NOT NULL,
  `Product_ID` int NOT NULL,
  `BatchNum` varchar(50) NOT NULL,
  `ExpirationDate` date NOT NULL,
  `Quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `expiration`
--

INSERT INTO `expiration` (`Expiration_ID`, `Product_ID`, `BatchNum`, `ExpirationDate`, `Quantity`) VALUES
(1, 15, 'BATCH-15-001', '2027-10-14', -9),
(2, 16, 'BATCH-16-001', '2025-11-14', 0),
(3, 17, 'BATCH-17-001', '2025-10-18', 2),
(4, 18, 'BATCH-18-001', '2025-10-18', 0),
(5, 18, 'BATCH-18-002', '2025-10-25', -10),
(6, 18, 'BATCH-18-003', '2025-10-28', 0),
(7, 18, 'BATCH-18-004', '2025-10-27', 1),
(8, 18, 'BATCH-18-005', '2025-11-19', 1);
