
-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `Product_ID` int NOT NULL,
  `LocationS` varchar(100) NOT NULL,
  `LocationR` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Inventory` int DEFAULT NULL,
  `UnitIN` datetime DEFAULT NULL,
  `UnitOut` timestamp NULL DEFAULT NULL,
  `Status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ExpirationDate` date DEFAULT NULL,
  `Barcode` varchar(100) NOT NULL,
  `Supplier_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`Product_ID`, `LocationS`, `LocationR`, `Price`, `Inventory`, `UnitIN`, `UnitOut`, `Status`, `ExpirationDate`, `Barcode`, `Supplier_ID`) VALUES
(2, 'Shelf A', 'Row A', 1000.00, 114, '2025-10-07 11:34:00', '2025-10-07 03:43:15', 'IN-STOCK', '2025-09-20', '11111', 1),
(3, 'Shelf A', 'Row A', 10000.00, 222, '2025-10-07 11:35:00', NULL, 'IN-STOCK', NULL, '11111', 2),
(9, 'Shelf A', 'Row A', 1000.00, 11, '2025-10-15 13:27:42', '2025-10-07 06:24:34', 'IN-STOCK', NULL, '20250900006', 1),
(11, 'Shelf A', 'Row A', 11400.00, 16, '2025-10-17 16:23:41', '2025-10-07 06:26:38', 'IN-STOCK', NULL, '20250900006', 1),
(12, 'Shelf A', 'Row A', 1000.00, 0, '2025-10-07 14:20:00', '2025-10-08 04:06:14', 'OUT-OF-STOCK', NULL, '20250900006', 1),
(13, 'Shelf A', 'Row A', 1000.00, 2, '2025-10-11 00:13:00', '2025-10-14 02:46:50', 'LOW-STOCK', NULL, '20250900006', 1),
(14, 'Shelf A', 'Row A', 800.00, 0, '2025-10-14 10:49:00', '2025-10-15 06:37:30', 'OUT-OF-STOCK', NULL, '20250900006', 1),
(15, 'Shelf C', 'Row D', 10099.00, 3, '2025-10-14 13:37:00', '2025-10-14 05:48:08', 'LOW-STOCK', '2027-10-14', '20250900006', 2),
(16, 'Shelf A', 'Row A', 10002.00, 12, '2025-10-16 14:25:58', '2025-10-17 04:41:09', 'IN-STOCK', '2025-11-14', '20250900006', 2),
(17, 'Shelf A', 'Row A', 50001.00, 1206, '2025-10-16 14:20:10', '2025-10-16 03:56:17', 'IN-STOCK', '2025-10-18', '20250900006', 2),
(18, 'Shelf A', 'Row A', 100.00, 222222263, '2025-10-15 13:41:05', '2025-10-17 04:39:18', 'IN-STOCK', '2025-10-18', '20250900006', 1),
(19, 'Shelf A', 'Row A', 1200.00, NULL, '2025-10-17 16:53:49', NULL, 'OUT-OF-STOCK', NULL, '20250900006', 2),
(20, 'Shelf A', 'Row A', 2000.00, 10, '2025-10-17 16:55:02', '2025-10-17 01:24:16', 'LOW-STOCK', NULL, '20250900006', 1);
