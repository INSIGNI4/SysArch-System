
-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` int NOT NULL,
  `ProductName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Type` enum('Exhaust','Tires','Brakes','Stand','Forks','Rims','Mirror','Suspension','Box','Oil') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ReordingPoints` int DEFAULT NULL,
  `UnitsOrdered` int DEFAULT NULL,
  `UnitSold` int DEFAULT NULL,
  `StorePrice` int NOT NULL,
  `SupplierPrice` int NOT NULL,
  `Image` blob,
  `Supplier_ID` int NOT NULL,
  `ExpirationDate` date DEFAULT NULL,
  `Barcode` varchar(100) NOT NULL,
  `LocationS` text NOT NULL,
  `LocationR` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `ProductName`, `Type`, `ReordingPoints`, `UnitsOrdered`, `UnitSold`, `StorePrice`, `SupplierPrice`, `Image`, `Supplier_ID`, `ExpirationDate`, `Barcode`, `LocationS`, `LocationR`) VALUES
(1, 'TRC Racing Honda XRM 110 Power Pipe', 'Tires', 10, 30, 30, 2500, 2200, 0x363863643839373934653761335f73686f7070696e672e77656270, 1, NULL, '1100110011', '', ''),
(2, 'MIRROR', 'Mirror', 10, 22, NULL, 1000, 800, 0x363863653030633337323030655f73686f7070696e672e77656270, 1, '2025-09-20', '20250900003', '', ''),
(3, 'MIRROR2', 'Mirror', 10, 10, NULL, 10000, 8000, 0x363864636564313963333832395f73686f7070696e672e77656270, 2, NULL, '20250900003', '', ''),
(4, 'MIRROR3', 'Mirror', 10, NULL, NULL, 1000, 100, NULL, 1, '2025-09-22', '20250900003', '', ''),
(5, 'Honda Rims 123', 'Rims', NULL, NULL, NULL, 5000, 4000, NULL, 1, NULL, '20250900003', '', ''),
(6, 'Exhaust RUSSI', 'Exhaust', NULL, NULL, NULL, 3000, 2800, NULL, 2, NULL, '20250900006', '', ''),
(7, 'TRC Racing Honda XRM 110 Power Pipe', 'Exhaust', NULL, NULL, NULL, 2300, 2000, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(8, 'PASTILLAS', 'Stand', NULL, NULL, NULL, 100, 10, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(9, 'cake', 'Brakes', NULL, 58, 47, 1000, 10, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(11, 'Russi', 'Exhaust', NULL, 41, 25, 11400, 10000, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(12, 'Payong', 'Exhaust', NULL, 15, 15, 1000, 100, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(13, '0000000', 'Tires', NULL, 10, 8, 1000, 100, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(14, 'Safeguard', 'Tires', NULL, 20, 20, 800, 500, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A'),
(15, 'TINAPAY', 'Tires', NULL, 25, 24, 10099, 5, NULL, 2, '2027-10-14', '20250900006', 'Shelf C', 'Row D'),
(16, 'SUMAN', 'Brakes', NULL, 32, 20, 10002, 100, NULL, 2, '2025-11-14', '20250900006', 'Shelf A', 'Row A'),
(17, 'LUMPIA', 'Forks', NULL, 1226, 20, 50001, 50, NULL, 2, '2025-10-18', '20250900006', 'Shelf A', 'Row A'),
(18, 'Saging', 'Tires', NULL, 222222328, 65, 100, 50, NULL, 1, '2025-10-18', '20250900006', 'Shelf A', 'Row A'),
(19, 'Bangus', 'Oil', NULL, NULL, 0, 1200, 80, NULL, 2, NULL, '20250900006', 'Shelf A', 'Row A'),
(20, 'hipon', 'Forks', NULL, 15, 5, 2000, 200, NULL, 1, NULL, '20250900006', 'Shelf A', 'Row A');

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `new_product_to_invetory` AFTER INSERT ON `product` FOR EACH ROW BEGIN
    DECLARE v_Price DECIMAL(10,2);
    DECLARE v_Supplier_ID VARCHAR(50);
    DECLARE v_ExpirationDate DATE;
    DECLARE v_Barcode VARCHAR(100);
    DECLARE v_NewInventory INT;
    DECLARE v_Status VARCHAR(20);
    DECLARE v_NewRestock DATE;

    
    
    
    
    
    
    
    
    
    
    

    -- Get product details
    SELECT StorePrice, Supplier_ID, ExpirationDate, Barcode
    INTO v_Price, v_Supplier_ID, v_ExpirationDate, v_Barcode
    FROM product
    WHERE Product_ID = NEW.Product_ID;

    -- Compute new inventory
    SET v_NewInventory = NEW.UnitsOrdered - NEW.UnitSold;

    -- Determine stock status
    SET v_Status = CASE 
        WHEN v_NewInventory > 10 THEN 'IN-STOCK'
        WHEN v_NewInventory > 0 THEN 'LOW-STOCK'
        ELSE 'OUT-OF-STOCK'
    END;

    -- Get most recent restock date
    SELECT Date_Received INTO v_NewRestock
    FROM restock 
    WHERE Product_ID = NEW.Product_ID
    ORDER BY Date_Received DESC
    LIMIT 1;

    -- Check if inventory exists
    IF EXISTS (
        SELECT 1 FROM inventory
        WHERE Product_ID = NEW.Product_ID
          AND LocationS = NEW.LocationS
          AND LocationR = NEW.LocationR
    ) THEN
        UPDATE inventory
        SET 
            Inventory = v_NewInventory,
            UnitIN = v_NewRestock,
            Status = v_Status,
            ExpirationDate = v_ExpirationDate,
            Price = v_Price,
            Barcode = v_Barcode
        WHERE Product_ID = NEW.Product_ID
          AND LocationS = NEW.LocationS
          AND LocationR = NEW.LocationR;
    ELSE
        INSERT INTO inventory (
            Product_ID,
            LocationS,
            LocationR,
            Price,
            Inventory,
            UnitIN,
            UnitOut,
            Status,
            Supplier_ID,
            ExpirationDate,
            Barcode
        ) VALUES (
            NEW.Product_ID,
            NEW.LocationS,
            NEW.LocationR,
            v_Price,
            v_NewInventory,
            v_NewRestock,
            NULL,
            v_Status,
            v_Supplier_ID,
            v_ExpirationDate,
            v_Barcode
        );
    END IF;


END
$$
DELIMITER ;
