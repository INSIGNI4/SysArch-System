
-- --------------------------------------------------------

--
-- Table structure for table `restock`
--

CREATE TABLE `restock` (
  `Orestock_ID` int NOT NULL,
  `Type` enum('New','Re-Order') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `OrderDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Product_ID` int NOT NULL,
  `Supplier_ID` int NOT NULL,
  `Status` enum('Requested','Out-for-Delivery','Cancelled','Received') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Image` blob,
  `DeliveryStatus` enum('','On-Time','Delayed','Early') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Date_Received` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `TotalReceived` int DEFAULT NULL,
  `withIssue` int DEFAULT '0',
  `ExpirationDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `restock`
--

INSERT INTO `restock` (`Orestock_ID`, `Type`, `Quantity`, `OrderDate`, `Product_ID`, `Supplier_ID`, `Status`, `Image`, `DeliveryStatus`, `Date_Received`, `TotalReceived`, `withIssue`, `ExpirationDate`) VALUES
(10, 'New', 10, '2025-10-07 02:09:00', 2, 2, 'Received', '', '', '2025-10-07 05:00:45', 0, 0, NULL),
(11, 'New', 10, '2025-10-07 02:13:00', 1, 1, 'Received', '', '', '2025-10-07 05:00:45', 10, 0, NULL),
(12, 'New', 10, '2025-10-07 02:22:00', 1, 1, 'Received', '', '', '2025-10-07 05:00:45', 10, 0, NULL),
(13, 'Re-Order', 12, '2025-10-07 04:01:04', 4, 1, 'Received', '', '', '2025-10-07 05:00:45', 12, 0, NULL),
(14, 'New', 12, '2025-10-07 04:02:50', 2, 2, 'Received', '', '', '2025-10-07 05:00:45', 12, 0, NULL),
(15, 'New', 12, '2025-10-07 04:11:43', 9, 1, 'Received', '', '', '2025-10-07 05:00:45', 12, 0, NULL),
(16, 'Re-Order', 10, '2025-10-07 05:08:07', 9, 2, 'Received', '', '', '2025-10-07 05:26:00', 10, 0, NULL),
(17, 'Re-Order', 10, '2025-10-07 05:18:52', 2, 2, 'Received', '', NULL, NULL, 0, 0, NULL),
(18, 'New', 12, '2025-10-07 05:21:46', 5, 1, 'Received', '', 'On-Time', '2025-10-07 05:25:00', 12, 0, NULL),
(19, 'Re-Order', 12, '2025-10-07 05:28:25', 9, 2, 'Received', '', 'On-Time', '2025-10-07 05:28:00', 12, 0, NULL),
(20, 'New', 1, '2025-10-07 05:29:27', 9, 2, 'Received', '', 'Early', '2025-10-07 05:30:00', 1, 0, NULL),
(21, 'Re-Order', 12, '2025-10-07 05:43:32', 9, 1, 'Received', '', 'Early', '2025-10-07 05:44:00', 12, 0, NULL),
(22, 'New', 15, '2025-10-07 06:09:13', 11, 1, 'Received', '', 'On-Time', '2025-10-07 06:10:00', 15, 0, NULL),
(23, 'Re-Order', 10, '2025-10-07 06:17:49', 11, 1, 'Received', '', 'On-Time', '2025-10-07 06:18:00', 10, 0, NULL),
(24, 'New', 15, '2025-10-07 06:20:37', 12, 1, 'Received', '', 'On-Time', '2025-10-07 06:20:00', 15, 0, NULL),
(25, 'New', 10, '2025-10-10 16:13:29', 13, 1, 'Received', '', 'On-Time', '2025-10-10 16:13:00', 10, 0, NULL),
(26, 'New', 20, '2025-10-14 02:49:10', 14, 2, 'Received', '', 'On-Time', '2025-10-14 02:49:00', 20, 0, NULL),
(27, NULL, 20, '2025-10-14 05:31:48', 15, 3, 'Received', '', 'Delayed', '2025-10-14 05:32:00', 20, 0, NULL),
(28, NULL, 5, '2025-10-14 05:37:31', 15, 2, 'Received', '', 'Delayed', '2025-10-14 05:37:00', 5, 0, NULL),
(29, NULL, 20, '2025-10-14 05:49:26', 16, 2, 'Received', '', 'Early', '2025-10-14 05:49:00', 20, 0, NULL),
(30, NULL, 20, '2025-10-14 05:57:18', 17, 3, 'Received', '', 'On-Time', '2025-10-14 05:57:00', 20, 0, NULL),
(31, NULL, 20, '2025-10-14 07:32:46', 18, 2, 'Received', '', 'On-Time', '2025-10-14 07:32:46', 20, 0, '2025-10-18'),
(32, NULL, 10, '2025-10-14 07:33:42', 18, 3, 'Received', '', 'Delayed', '2025-10-14 07:33:42', 10, 0, '2025-10-25'),
(33, NULL, 20, '2025-10-14 07:42:28', 18, 1, 'Received', '', 'Delayed', '2025-10-14 07:42:28', 20, 0, '2025-10-28'),
(34, NULL, 5, '2025-10-14 07:44:12', 18, 2, 'Received', '', 'On-Time', '2025-10-14 07:44:12', 12, 0, '2025-10-18'),
(35, NULL, 20, '2025-10-14 08:24:23', 18, 3, 'Received', '', 'Delayed', '2025-10-14 08:24:23', 20, 0, '2025-10-27'),
(36, NULL, 20, '2025-10-14 08:45:26', 18, 1, 'Received', '', 'Delayed', '2025-10-14 08:45:26', 20, 0, '2025-11-19'),
(37, NULL, 10, '2025-10-15 04:33:15', 18, 3, 'Received', NULL, 'Delayed', '2025-10-15 04:33:15', 11, 0, NULL),
(38, NULL, 20, '2025-10-15 05:11:55', 17, 3, 'Received', NULL, 'On-Time', '2025-10-15 05:11:55', 2222222, 0, NULL),
(39, NULL, 20, '2025-10-15 05:14:59', 17, 1, 'Received', NULL, 'Delayed', '2025-10-15 05:14:59', 21, 0, NULL),
(40, NULL, 20, '2025-10-15 05:18:23', 17, 2, 'Received', NULL, 'Early', '2025-10-15 05:18:23', 21, 0, NULL),
(41, NULL, 10, '2025-10-15 05:27:42', 9, 3, 'Received', NULL, 'Delayed', '2025-10-15 05:27:42', 11, 1, NULL),
(42, NULL, 10, '2025-10-15 05:30:31', 17, 3, 'Received', NULL, 'Early', '2025-10-15 05:30:31', 11, 0, NULL),
(43, NULL, 1, '2025-10-15 05:41:05', 18, 3, 'Received', NULL, 'Delayed', '2025-10-15 05:41:05', 222222222, 0, NULL),
(44, NULL, 99, '2025-10-15 05:46:34', 18, 1, 'Cancelled', NULL, 'Early', '2025-10-15 05:46:34', 100, 0, NULL),
(45, NULL, 10, '2025-10-15 06:03:29', 17, 2, 'Received', NULL, 'Delayed', '2025-10-15 06:03:29', 11, 0, NULL),
(46, NULL, 10, '2025-10-15 06:05:35', 17, 1, 'Received', NULL, 'On-Time', '2025-10-15 06:05:35', 1111, 0, NULL),
(47, NULL, 12, '2025-10-15 06:10:41', 17, 3, 'Requested', NULL, NULL, '2025-10-15 06:10:41', 0, 0, NULL),
(50, NULL, 20, '2025-10-15 06:42:04', 16, 2, 'Received', NULL, 'Delayed', '2025-10-15 06:42:04', 2, 18, NULL),
(51, NULL, 10, '2025-10-16 06:20:10', 17, 3, 'Received', NULL, 'Early', '2025-10-16 06:20:10', 10, 0, NULL),
(52, NULL, 10, '2025-10-16 06:25:58', 16, 3, 'Received', NULL, 'On-Time', '2025-10-16 06:25:58', 10, 0, NULL),
(53, NULL, 20, '2025-10-17 08:23:41', 11, 2, 'Received', NULL, 'Delayed', '2025-10-17 08:23:41', 15, 5, NULL),
(54, NULL, 20, '2025-10-17 08:44:57', 19, 1, 'Received', NULL, 'Delayed', '2025-10-17 08:44:57', 10, 10, NULL),
(55, NULL, 20, '2025-10-17 08:50:53', 19, 4, 'Received', NULL, '', '2025-10-17 08:50:53', 20, 0, NULL),
(56, NULL, 20, '2025-10-17 08:52:51', 19, 5, 'Received', NULL, 'Early', '2025-10-17 08:52:51', 20, 0, NULL),
(57, NULL, 20, '2025-10-17 08:53:49', 19, 3, 'Received', NULL, 'On-Time', '2025-10-17 08:53:49', 20, 0, NULL),
(58, NULL, 20, '2025-10-17 08:55:02', 20, 4, 'Received', NULL, 'Delayed', '2025-10-17 08:55:02', 15, 5, NULL);

--
-- Triggers `restock`
--
DELIMITER $$
CREATE TRIGGER `update_product_unitorder` BEFORE UPDATE ON `restock` FOR EACH ROW BEGIN
    DECLARE v_NewInventory INT;
    DECLARE new_status VARCHAR(20);
    DECLARE v_BatchNum VARCHAR(50);
    DECLARE v_BatchCount INT;
    DECLARE v_ReceivedDiff INT DEFAULT 0;

    -- Use IFNULL to avoid NULL arithmetic (NULL - anything => NULL)
    SET v_ReceivedDiff = IFNULL(NEW.TotalReceived, 0) - IFNULL(OLD.TotalReceived, 0);

    -- Only act when the record is (now) marked as Received
    IF NEW.Status = 'Received' THEN

        -- Adjust UnitsOrdered by the difference (guard against negative final value)
        UPDATE product
        SET UnitsOrdered = GREATEST(IFNULL(UnitsOrdered, 0) + v_ReceivedDiff, 0)
        WHERE Product_ID = NEW.Product_ID;

        -- Recalculate inventory from product (ensure product values are not NULL)
        SELECT IFNULL(UnitsOrdered, 0) - IFNULL(UnitSold, 0)
        INTO v_NewInventory
        FROM product
        WHERE Product_ID = NEW.Product_ID;

        -- Determine stock status
        SET new_status = CASE 
            WHEN v_NewInventory > 10 THEN 'IN-STOCK'
            WHEN v_NewInventory > 0 THEN 'LOW-STOCK'
            ELSE 'OUT-OF-STOCK'
        END;

        -- Update inventory table
        UPDATE inventory
        SET 
            UnitIN = NEW.Date_Received,
            Inventory = v_NewInventory,
            Status = new_status
        WHERE Product_ID = NEW.Product_ID;
    END IF;

    -- Handle expiration batches (only if an expiration date exists)
    IF NEW.ExpirationDate IS NOT NULL THEN
        SELECT COUNT(*) + 1 INTO v_BatchCount
        FROM expiration
        WHERE Product_ID = NEW.Product_ID;

        SET v_BatchNum = CONCAT('BATCH-', NEW.Product_ID, '-', LPAD(v_BatchCount, 3, '0'));

        IF EXISTS (
            SELECT 1 FROM expiration 
            WHERE Product_ID = NEW.Product_ID 
              AND ExpirationDate = NEW.ExpirationDate
        ) THEN
            -- Adjust existing expiration batch quantity; don't allow negative result
            UPDATE expiration
            SET Quantity = GREATEST(IFNULL(Quantity, 0) + v_ReceivedDiff, 0)
            WHERE Product_ID = NEW.Product_ID 
              AND ExpirationDate = NEW.ExpirationDate;
        ELSE
            -- Insert a new expiration batch only if there's positive quantity to add
            IF IFNULL(NEW.TotalReceived, 0) > 0 THEN
                INSERT INTO expiration (Product_ID, BatchNum, ExpirationDate, Quantity)
                VALUES (NEW.Product_ID, v_BatchNum, NEW.ExpirationDate, NEW.TotalReceived);
            END IF;
        END IF;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_restock_request` BEFORE UPDATE ON `restock` FOR EACH ROW BEGIN
	-- UPDATE restock
	-- SET 
    -- Product_ID = New.Product_ID,
	-- Supplier_ID = New.Supplier_ID,
    -- Quantity = New.Quantity;
END
$$
DELIMITER ;
