
-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `Order_ID` int NOT NULL,
  `Transaction_ID` int NOT NULL,
  `Product_ID` int NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Unit_Price` int NOT NULL,
  `Quantity` int NOT NULL,
  `TotalPrice` int DEFAULT NULL,
  `Barcode` varchar(100) NOT NULL,
  `SalesDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id` int DEFAULT NULL,
  `BatchNum` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Order_ID`, `Transaction_ID`, `Product_ID`, `ProductName`, `Unit_Price`, `Quantity`, `TotalPrice`, `Barcode`, `SalesDate`, `id`, `BatchNum`) VALUES
(91, 7, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 2, 5000, '1100110011', '2025-10-04 01:16:00', NULL, NULL),
(92, 8, 2, 'MIRROR', 1000, 2, 2000, '11111', '2025-10-04 01:19:00', NULL, NULL),
(93, 8, 3, 'MIRROR2', 10000, 10, 100000, '11111', '2025-10-04 01:20:00', NULL, NULL),
(94, 8, 4, 'MIRROR3', 1000, 10, 10000, '11111111111', '2025-10-04 01:20:00', NULL, NULL),
(95, 8, 5, 'Honda Rims 123', 5000, 5, 25000, '20250900003', '2025-10-04 01:20:00', NULL, NULL),
(96, 7, 4, 'MIRROR3', 1000, 2, 2000, '11111111111', '2025-10-04 06:33:00', NULL, NULL),
(97, 7, 2, 'MIRROR', 1000, 2, 2000, '11111', '2025-10-03 06:34:00', NULL, NULL),
(98, 8, 2, 'MIRROR', 1000, 2, 2000, '11111', '2025-10-02 06:34:00', NULL, NULL),
(99, 7, 3, 'MIRROR2', 10000, 12, 120000, '11111', '2025-10-03 06:35:00', NULL, NULL),
(100, 9, 3, 'MIRROR2', 10000, 5, 50000, '11111', '2025-10-02 07:41:00', NULL, NULL),
(101, 8, 2, 'MIRROR', 1000, 110, 110000, '11111', '2025-10-01 07:57:00', NULL, NULL),
(102, 8, 2, 'MIRROR', 1000, 2, 2000, '11111', '2025-10-07 03:41:54', NULL, NULL),
(103, 8, 2, 'MIRROR', 1000, 2, 2000, '11111', '2025-10-07 03:43:15', NULL, NULL),
(104, 8, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 5, 12500, '1100110011', '2025-10-07 03:54:50', NULL, NULL),
(105, 8, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 2, 5000, '1100110011', '2025-10-07 03:58:22', NULL, NULL),
(106, 7, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 2, 5000, '1100110011', '2025-10-07 03:59:23', NULL, NULL),
(107, 9, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 2, 5000, '1100110011', '2025-10-07 04:06:42', NULL, NULL),
(108, 9, 9, 'cake', 1000, 2, 2000, '20250900006', '2025-10-07 04:11:22', NULL, NULL),
(109, 7, 9, 'cake', 1000, 1, 1000, '20250900006', '2025-10-07 04:17:36', NULL, NULL),
(111, 7, 9, 'cake', 1000, 2, 2000, '20250900006', '2025-10-07 04:31:23', NULL, NULL),
(112, 8, 9, 'cake', 1000, 1, 1000, '20250900006', '2025-10-07 05:27:39', NULL, NULL),
(113, 7, 9, 'cake', 1000, 3, 3000, '20250900006', '2025-10-07 05:45:03', NULL, NULL),
(114, 10, 9, 'cake', 1000, 10, 10000, '20250900006', '2025-10-07 05:49:36', NULL, NULL),
(115, 7, 12, 'Payong', 1000, 11, 11000, '20250900006', '2025-10-07 06:22:14', NULL, NULL),
(116, 8, 9, 'cake', 1000, 30, 30000, '20250900006', '2025-10-07 06:24:34', NULL, NULL),
(117, 8, 11, 'Russi', 11400, 25, 285000, '20250900006', '2025-10-07 06:26:38', NULL, NULL),
(118, 8, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 0, 0, '1100110011', '2025-10-08 04:05:06', NULL, NULL),
(119, 7, 1, 'TRC Racing Honda XRM 110 Power Pipe', 2500, 20, 50000, '1100110011', '2025-10-08 04:05:37', NULL, NULL),
(120, 7, 12, 'Payong', 1000, 4, 4000, '20250900006', '2025-10-08 04:06:14', NULL, NULL),
(123, 9, 13, '0000000', 1000, 2, 2000, '20250900006', '2025-10-12 03:01:49', NULL, NULL),
(128, 14, 13, '0000000', 1000, 2, 2000, '20250900006', '2025-10-14 02:37:42', NULL, NULL),
(129, 14, 13, '0000000', 1000, 2, 2000, '20250900006', '2025-10-14 02:40:42', NULL, NULL),
(130, 14, 13, '0000000', 1000, 2, 2000, '20250900006', '2025-10-14 02:46:50', NULL, NULL),
(131, 14, 14, 'Safeguard', 800, 10, 8000, '20250900006', '2025-10-14 02:49:51', NULL, NULL),
(132, 14, 15, 'TINAPAY', 10099, 5, 50495, '20250900006', '2025-10-14 05:40:53', NULL, NULL),
(133, 7, 15, 'TINAPAY', 10099, 5, 50495, '20250900006', '2025-10-14 05:43:31', NULL, NULL),
(134, 7, 15, 'TINAPAY', 10099, 4, 40396, '20250900006', '2025-10-14 05:44:53', NULL, NULL),
(135, 7, 15, 'TINAPAY', 10099, 1, 10099, '20250900006', '2025-10-14 05:45:47', NULL, NULL),
(136, 8, 15, 'TINAPAY', 10099, 1, 10099, '20250900006', '2025-10-14 05:47:30', NULL, NULL),
(137, 10, 15, 'TINAPAY', 10099, 1, 10099, '20250900006', '2025-10-14 05:47:44', NULL, NULL),
(138, 11, 15, 'TINAPAY', 10099, 2, 20198, '20250900006', '2025-10-14 05:48:08', NULL, NULL),
(139, 12, 16, 'SUMAN', 10002, 5, 50010, '20250900006', '2025-10-14 05:50:19', NULL, NULL),
(140, 8, 16, 'SUMAN', 10002, 1, 10002, '20250900006', '2025-10-14 05:53:17', NULL, NULL),
(141, 10, 17, 'LUMPIA', 50001, 7, 350007, '20250900006', '2025-10-14 05:58:03', NULL, NULL),
(142, 11, 18, 'Saging', 100, 20, 2000, '20250900006', '2025-10-14 07:45:17', NULL, NULL),
(143, 11, 18, 'Saging', 100, 5, 500, '20250900006', '2025-10-14 08:46:20', NULL, 'BATCH-18-005'),
(144, 8, 17, 'LUMPIA', 50001, 2, 100002, '20250900006', '2025-10-14 08:47:24', NULL, NULL),
(145, 10, 18, 'Saging', 100, 5, 500, '20250900006', '2025-10-14 08:47:52', NULL, 'BATCH-18-004'),
(146, 8, 18, 'Saging', 100, 10, 1000, '20250900006', '2025-10-14 08:48:28', NULL, 'BATCH-18-004'),
(147, 14, 16, 'SUMAN', 10002, 2, 20004, '20250900006', '2025-10-15 06:28:22', NULL, 'BATCH-16-001'),
(148, 9, 14, 'Safeguard', 800, 2, 1600, '20250900006', '2025-10-15 06:36:32', NULL, NULL),
(149, 9, 14, 'Safeguard', 800, 2, 1600, '20250900006', '2025-10-15 06:37:09', NULL, NULL),
(150, 9, 14, 'Safeguard', 800, 2, 1600, '20250900006', '2025-10-15 06:37:22', NULL, NULL),
(151, 9, 14, 'Safeguard', 800, 2, 1600, '20250900006', '2025-10-15 06:37:25', NULL, NULL),
(152, 9, 14, 'Safeguard', 800, 2, 1600, '20250900006', '2025-10-15 06:37:30', NULL, NULL),
(153, 10, 16, 'SUMAN', 10002, 2, 20004, '20250900006', '2025-10-15 06:38:53', NULL, 'BATCH-16-001'),
(154, 10, 16, 'SUMAN', 10002, 2, 20004, '20250900006', '2025-10-15 06:39:48', NULL, 'BATCH-16-001'),
(155, 9, 18, 'Saging', 100, 12, 1200, '20250900006', '2025-10-15 06:44:22', NULL, 'BATCH-18-005'),
(156, 9, 17, 'LUMPIA', 50001, 9, 450009, '20250900006', '2025-10-15 06:47:20', NULL, 'BATCH-17-001'),
(157, 8, 17, 'LUMPIA', 50001, 2, 100002, '20250900006', '2025-10-16 03:56:17', NULL, 'BATCH-17-001'),
(158, 8, 16, 'SUMAN', 10002, 5, 50010, '20250900006', '2025-10-16 04:27:47', NULL, 'BATCH-16-001'),
(159, 13, 18, 'Saging', 100, 7, 700, '20250900006', '2025-10-16 04:28:42', NULL, 'BATCH-18-001'),
(160, 8, 16, 'SUMAN', 10002, 2, 20004, 'undefined', '2025-10-16 06:05:45', NULL, 'BATCH-16-001'),
(161, 15, 18, 'Saging', 100, 3, 300, '20250900006', '2025-10-17 01:24:42', NULL, 'BATCH-18-004'),
(163, 16, 18, 'Saging', 100, 2, 200, '20250900006', '2025-10-17 04:40:25', NULL, 'BATCH-18-005'),
(164, 16, 16, 'SUMAN', 10002, 1, 10002, '20250900006', '2025-10-17 04:41:09', NULL, 'BATCH-16-001'),
(165, 16, 18, 'Saging', 100, 1, 100, '20250900006', '2025-10-17 04:42:27', NULL, 'BATCH-18-004'),
(166, 15, 20, 'hipon', 2000, 5, 10000, '20250900006', '2025-10-17 10:15:14', 1, NULL);

--
-- Triggers `sales`
--
DELIMITER $$
CREATE TRIGGER `after_insert_sales` AFTER INSERT ON `sales` FOR EACH ROW BEGIN
    -- UPDATE product
    -- SET UnitSold = UnitSold + NEW.Quantity
    -- WHERE Product_ID = NEW.Product_ID;
    
    -- UPDATE expiration
    -- SET Quantity = NEW.Quantity
    -- WHERE Product_ID = NEW.Product_ID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_sales_insert_aggregration` AFTER INSERT ON `sales` FOR EACH ROW BEGIN
    DECLARE daily_start DATE;
    DECLARE daily_end DATE;
    
    DECLARE weekly_start DATE;
    DECLARE weekly_end DATE;
    
    DECLARE monthly_start DATE;
    DECLARE monthly_end DATE;

    -- Compute period boundaries
    SET daily_start = DATE(NEW.SalesDate);
    SET daily_end = daily_start;

    SET weekly_start = DATE_SUB(NEW.SalesDate, INTERVAL WEEKDAY(NEW.SalesDate) DAY);
    SET weekly_end = DATE_ADD(weekly_start, INTERVAL 6 DAY);

    SET monthly_start = DATE_FORMAT(NEW.SalesDate, '%Y-%m-01');
    SET monthly_end = LAST_DAY(NEW.SalesDate);

    -- DAILY AGGREGATION
    INSERT INTO daily_sales (
        PeriodStart, PeriodEnd, Product_ID, TotalSales, TotalQuantity
    )
    VALUES (
         daily_start, daily_end, NEW.Product_ID, NEW.TotalPrice, NEW.Quantity
    )
    ON DUPLICATE KEY UPDATE
        TotalSales = TotalSales + NEW.TotalPrice,
        TotalQuantity = TotalQuantity + NEW.Quantity;

    -- WEEKLY AGGREGATION (no PeriodType)
    INSERT INTO weekly_sales (
        PeriodStart, PeriodEnd, Product_ID, TotalSales, TotalQuantity
    )
    VALUES (
        weekly_start, weekly_end, NEW.Product_ID, NEW.TotalPrice, NEW.Quantity
    )
    ON DUPLICATE KEY UPDATE
        TotalSales = TotalSales + NEW.TotalPrice,
        TotalQuantity = TotalQuantity + NEW.Quantity;

    -- MONTHLY AGGREGATION
    INSERT INTO monthly_sales (
         PeriodStart, PeriodEnd, Product_ID, TotalSales, TotalQuantity
    )
    VALUES (
         monthly_start, monthly_end, NEW.Product_ID, NEW.TotalPrice, NEW.Quantity
    )
    ON DUPLICATE KEY UPDATE
        TotalSales = TotalSales + NEW.TotalPrice,
        TotalQuantity = TotalQuantity + NEW.Quantity;



    -- DAILY TOTAL AGGREGATION (all products)
    INSERT INTO daily_total_sales (
        PeriodStart, PeriodEnd, TotalSales, TotalQuantity
    )
    VALUES (
        daily_start, daily_end, NEW.TotalPrice, NEW.Quantity
    )
    ON DUPLICATE KEY UPDATE
        TotalSales = TotalSales + NEW.TotalPrice,
        TotalQuantity = TotalQuantity + NEW.Quantity;

    -- WEEKLY TOTAL AGGREGATION (all products)
    INSERT INTO weekly_total_sales (
        PeriodStart, PeriodEnd, TotalSales, TotalQuantity
    )
    VALUES (
        weekly_start, weekly_end, TotalSales, TotalQuantity
    )
    ON DUPLICATE KEY UPDATE
        TotalSales = TotalSales + NEW.TotalPrice,
        TotalQuantity = TotalQuantity + NEW.Quantity;

    -- MONTHLY TOTAL AGGREGATION (all products)
    INSERT INTO monthly_total_sales (
        PeriodStart, PeriodEnd, TotalSales, TotalQuantity
    )
    VALUES (
        monthly_start, monthly_end, TotalSales, TotalQuantity
    )
    ON DUPLICATE KEY UPDATE
        TotalSales = TotalSales + NEW.TotalPrice,
        TotalQuantity = TotalQuantity + NEW.Quantity;








END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_sales_insert_inventory` AFTER INSERT ON `sales` FOR EACH ROW BEGIN
    DECLARE current_inventory INT DEFAULT 0;
    DECLARE new_inventory INT DEFAULT 0;
    DECLARE new_status VARCHAR(20);
    DECLARE TransactionDate DATETIME;

    -- 1️⃣ Get current inventory for this product
    SELECT Inventory INTO current_inventory
    FROM inventory
    WHERE Product_ID = NEW.Product_ID
    LIMIT 1;

    -- 2️⃣ Compute new inventory
    SET new_inventory = current_inventory - NEW.Quantity;
    
    SELECT Transaction_Date INTO TransactionDate
    FROM transactions
    WHERE Transaction_ID = NEW.Transaction_ID;

    -- 3️⃣ Determine stock status
    SET new_status = CASE 
        WHEN new_inventory > 10 THEN 'IN-STOCK'
        WHEN new_inventory > 0 THEN 'LOW-STOCK'
        ELSE 'OUT-OF-STOCK'
    END;

    -- 4️⃣ Update main inventory table
    UPDATE inventory
    SET 
        Inventory = new_inventory,
        -- UnitOut = NEW.SalesDate,
        UnitOut = TransactionDate,
        Status = new_status
    WHERE Product_ID = NEW.Product_ID;

    -- 5️⃣ Update total sold units in product table
    UPDATE product
    SET UnitSold = UnitSold + NEW.Quantity
    WHERE Product_ID = NEW.Product_ID;

    -- 6️⃣ Deduct from the correct expiration batch only
    UPDATE expiration
    SET Quantity = Quantity - NEW.Quantity
    WHERE Product_ID = NEW.Product_ID
      AND BatchNum = NEW.BatchNum; 

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_sales_update_inventory` BEFORE UPDATE ON `sales` FOR EACH ROW BEGIN
    DECLARE new_inventory INT;
    DECLARE new_status VARCHAR(20);

    -- Calculate new inventory from product table
    SELECT UnitsOrdered - UnitSold INTO new_inventory
    FROM product
    WHERE Product_ID = NEW.Product_ID;

    -- Determine the new status
    SET new_status = CASE 
        WHEN new_inventory > 10 THEN 'IN-STOCK'
        WHEN new_inventory > 0 THEN 'LOW-STOCK'
        ELSE 'OUT-OF-STOCK'
    END;

    -- Update the inventory table
    UPDATE inventory
    SET 
        Inventory = new_inventory,
        UnitOut = NEW.SalesDate,
        Status = new_status
    WHERE Product_ID = NEW.Product_ID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `sales_to_transactions` AFTER INSERT ON `sales` FOR EACH ROW BEGIN
    -- Update the inventory table
    
    DECLARE Price INT;
    SET Price = New.TotalPrice;
    
    UPDATE transactions
    SET 
        Total_Price = COALESCE(Total_Price, 0) + Price
        -- UnitOut = NEW.SalesDate,
        -- Status = new_status
    WHERE Transaction_ID = NEW.Transaction_ID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `sales_to_transactions_UPDATE` AFTER UPDATE ON `sales` FOR EACH ROW BEGIN
    DECLARE price_difference DECIMAL(10,2);

    -- Compute the difference between new and old total prices
    SET price_difference = NEW.TotalPrice - OLD.TotalPrice;

    -- Apply only the difference to the transaction's total
    UPDATE transactions
    SET Total_Price = COALESCE(Total_Price, 0) + price_difference
    WHERE Transaction_ID = NEW.Transaction_ID;
END
$$
DELIMITER ;
