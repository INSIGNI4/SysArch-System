
-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `Supplier_ID` int NOT NULL,
  `SupplierName` varchar(100) NOT NULL,
  `Location` varchar(250) NOT NULL,
  `Email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PhoneNumber` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `OfferedProductsType` enum('Exhaust','Tires','Brakes','Stand','Forks','Rims','Mirror','Suspension','Box','Oil') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`Supplier_ID`, `SupplierName`, `Location`, `Email`, `PhoneNumber`, `OfferedProductsType`) VALUES
(1, 'James', 'Caloocan', 'James2025@gmail.com', '0938572641', 'Exhaust'),
(2, 'Clark', 'Malabon', 'Clark@gmail.com', '09384723512', 'Tires'),
(3, 'Michael', 'Caloocan', 'Michael@gmail.com', '09837284652', 'Exhaust'),
(4, 'KALOY', 'BULACAN', 'gomezcarlo333@gmail.com', '09382747531', 'Tires'),
(5, 'KALOY', 'Bulacan', 'gomezcarlo333@gmail.com', '09382747531', 'Brakes');
