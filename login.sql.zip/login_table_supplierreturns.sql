
-- --------------------------------------------------------

--
-- Table structure for table `supplierreturns`
--

CREATE TABLE `supplierreturns` (
  `SReturns_ID` int NOT NULL,
  `Supplier_ID` int NOT NULL,
  `Product_ID` int NOT NULL,
  `Quantity` int NOT NULL,
  `ReturnedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` enum('Pending','Out-for-Delivery','Cancelled','Delivered') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Reason` enum('Wrong-Item','Damaged','Missing-Parts','Accidental','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplierreturns`
--

INSERT INTO `supplierreturns` (`SReturns_ID`, `Supplier_ID`, `Product_ID`, `Quantity`, `ReturnedDate`, `Status`, `Reason`) VALUES
(28, 1, 2, 1, '2025-10-17 04:57:34', 'Delivered', 'Damaged'),
(29, 1, 2, 1, '2025-10-17 04:57:34', 'Delivered', 'Damaged'),
(30, 1, 2, 1, '2025-10-17 04:57:34', 'Delivered', 'Damaged'),
(31, 1, 2, 1, '2025-10-17 04:57:34', 'Delivered', 'Damaged'),
(32, 1, 2, 1, '2025-10-17 04:57:34', 'Delivered', 'Damaged'),
(33, 1, 4, 1, '2025-10-17 04:58:12', 'Delivered', 'Accidental'),
(34, 3, 18, 222, '2025-10-17 04:58:48', 'Delivered', 'Damaged'),
(35, 3, 1, 1, '2025-10-17 05:18:04', 'Pending', 'Wrong-Item'),
(36, 3, 3, 1, '2025-10-17 05:18:14', 'Out-for-Delivery', 'Damaged'),
(37, 3, 3, 1, '2025-10-17 05:18:24', 'Cancelled', 'Missing-Parts'),
(38, 3, 2, 1, '2025-10-17 05:18:37', 'Pending', 'Accidental'),
(39, 2, 4, 1, '2025-10-17 05:18:49', 'Out-for-Delivery', 'Other');
