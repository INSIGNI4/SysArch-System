
-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `Transaction_ID` int NOT NULL,
  `Customer_ID` int DEFAULT NULL,
  `ReferenceNo` varchar(100) NOT NULL,
  `PurchaseType` enum('','Online','Over-the-Counter') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PaymentMethod` enum('','Cash','eWallet') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ServiceType` enum('','Pick Up','Delivery') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Transaction_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Total_Price` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`Transaction_ID`, `Customer_ID`, `ReferenceNo`, `PurchaseType`, `PaymentMethod`, `ServiceType`, `Transaction_Date`, `Total_Price`) VALUES
(7, 3, '20250900001', 'Online', 'Cash', '', '2025-10-03 13:31:00', 100990),
(8, 4, '20250900002', 'Over-the-Counter', 'Cash', '', '2025-10-03 13:32:00', 291119),
(9, 3, '20250900001', 'Over-the-Counter', 'Cash', '', '2025-10-04 01:15:00', 459209),
(10, 4, '20250900001', 'Online', 'Cash', '', '2025-10-06 08:04:00', 400614),
(11, 3, '20250900001', 'Online', 'Cash', '', '2025-10-07 02:29:02', 22698),
(12, 3, '20250900001', 'Over-the-Counter', 'Cash', '', '2025-10-07 02:29:24', 50010),
(13, 5, '20250900002', 'Over-the-Counter', 'eWallet', 'Pick Up', '2025-10-07 02:31:09', 700),
(14, 8, '20250900001', 'Over-the-Counter', 'Cash', 'Pick Up', '2025-10-14 02:34:37', 80499),
(15, 4, '20250900010', 'Online', 'Cash', 'Delivery', '2025-10-17 01:24:16', 10300),
(16, 8, '20250900002', 'Online', 'eWallet', 'Pick Up', '2025-10-17 04:39:18', 10302);
