
-- --------------------------------------------------------

--
-- Structure for view `daily_sales_summary`
--
DROP TABLE IF EXISTS `daily_sales_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `daily_sales_summary`  AS SELECT `sales`.`Product_ID` AS `Product_ID`, `sales`.`ProductName` AS `ProductName`, `sales`.`SalesDate` AS `SalesDate`, sum(`sales`.`Quantity`) AS `TotalQuantity`, sum(`sales`.`TotalPrice`) AS `TotalRevenue` FROM `sales` GROUP BY `sales`.`Product_ID`, `sales`.`ProductName`, `sales`.`SalesDate` ORDER BY `sales`.`SalesDate` ASC, `sales`.`Product_ID` ASC ;
