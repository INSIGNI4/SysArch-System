
-- --------------------------------------------------------

--
-- Structure for view `v_sales_forecast`
--
DROP TABLE IF EXISTS `v_sales_forecast`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sales_forecast`  AS SELECT `sales`.`Product_ID` AS `Product_ID`, `sales`.`ProductName` AS `ProductName`, cast(`sales`.`SalesDate` as date) AS `SalesDate`, sum(`sales`.`Quantity`) AS `DailyQuantity`, round(avg(sum(`sales`.`Quantity`)) OVER (PARTITION BY `sales`.`Product_ID` ORDER BY cast(`sales`.`SalesDate` as date) ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) ,2) AS `MovingAverage3` FROM `sales` GROUP BY `sales`.`Product_ID`, `sales`.`ProductName`, cast(`sales`.`SalesDate` as date) ORDER BY `sales`.`Product_ID` ASC, cast(`sales`.`SalesDate` as date) ASC ;
