
-- --------------------------------------------------------

--
-- Structure for view `v_sales_next_forecast`
--
DROP TABLE IF EXISTS `v_sales_next_forecast`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sales_next_forecast`  AS SELECT `last3`.`Product_ID` AS `Product_ID`, `last3`.`ProductName` AS `ProductName`, (max(`last3`.`SalesDate`) + interval 1 day) AS `ForecastDate`, round(avg(`last3`.`DailyTotal`),2) AS `ForecastValue` FROM (select `sales`.`Product_ID` AS `Product_ID`,`sales`.`ProductName` AS `ProductName`,cast(`sales`.`SalesDate` as date) AS `SalesDate`,sum(`sales`.`TotalPrice`) AS `DailyTotal` from `sales` group by `sales`.`Product_ID`,`sales`.`ProductName`,cast(`sales`.`SalesDate` as date) order by `sales`.`Product_ID`,`SalesDate` desc limit 3) AS `last3` GROUP BY `last3`.`Product_ID`, `last3`.`ProductName` ;
