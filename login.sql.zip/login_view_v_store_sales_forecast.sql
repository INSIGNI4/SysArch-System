
-- --------------------------------------------------------

--
-- Structure for view `v_store_sales_forecast`
--
DROP TABLE IF EXISTS `v_store_sales_forecast`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_store_sales_forecast`  AS SELECT cast(`s`.`SalesDate` as date) AS `SalesDate`, sum(`s`.`Quantity`) AS `DailyTotalQuantity`, round(avg(sum(`s`.`Quantity`)) OVER (ORDER BY cast(`s`.`SalesDate` as date) ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) ,2) AS `MovingAverage3` FROM `sales` AS `s` GROUP BY cast(`s`.`SalesDate` as date) ORDER BY cast(`s`.`SalesDate` as date) ASC ;
