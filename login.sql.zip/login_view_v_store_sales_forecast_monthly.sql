
-- --------------------------------------------------------

--
-- Structure for view `v_store_sales_forecast_monthly`
--
DROP TABLE IF EXISTS `v_store_sales_forecast_monthly`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_store_sales_forecast_monthly`  AS SELECT date_format(`sales`.`SalesDate`,'%Y-%m') AS `Period`, sum(`sales`.`Quantity`) AS `TotalQuantity`, round(avg(sum(`sales`.`Quantity`)) OVER (ORDER BY date_format(`sales`.`SalesDate`,'%Y-%m') ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) ,2) AS `MovingAverage3` FROM `sales` GROUP BY date_format(`sales`.`SalesDate`,'%Y-%m') ORDER BY date_format(`sales`.`SalesDate`,'%Y-%m') ASC ;
