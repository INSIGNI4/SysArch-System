
-- --------------------------------------------------------

--
-- Structure for view `v_store_sales_forecast_weekly`
--
DROP TABLE IF EXISTS `v_store_sales_forecast_weekly`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_store_sales_forecast_weekly`  AS SELECT yearweek(`sales`.`SalesDate`,1) AS `Period`, sum(`sales`.`Quantity`) AS `TotalQuantity`, round(avg(sum(`sales`.`Quantity`)) OVER (ORDER BY yearweek(`sales`.`SalesDate`,1) ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) ,2) AS `MovingAverage3` FROM `sales` GROUP BY yearweek(`sales`.`SalesDate`,1) ORDER BY yearweek(`sales`.`SalesDate`,1) ASC ;
